//
//  MCORFC822.h
//  mailcore2
//
//  Created by DINH Viêt Hoà on 3/22/13.
//  Copyright (c) 2013 MailCore. All rights reserved.
//

#ifndef MAILCORE_MCORFC822_H

#define MAILCORE_MCORFC822_H

#import <MailCore/MCOAttachment.h>
#import <MailCore/MCOMessageBuilder.h>
#import <MailCore/MCOMessageParser.h>
#import <MailCore/MCOMessagePart.h>
#import <MailCore/MCOMultipart.h>

#endif
